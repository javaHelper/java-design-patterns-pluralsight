package com.definitionbuddy.dictionary;

import java.util.List;

public interface Dictionary  {

    List<String> getDefinitions(String word);

}
