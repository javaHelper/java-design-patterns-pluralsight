package com.definitionbuddy.search;

import java.util.List;

public interface DefinitionSearch {

    List<String> getDefinition(String word);
}
