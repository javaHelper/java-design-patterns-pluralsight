package com.definitionbuddy.dictionary;

/**
 * Dummy object that is added to Dictionary class to show increasing number of dependencies
 */
public class ExampleProvider {
}
