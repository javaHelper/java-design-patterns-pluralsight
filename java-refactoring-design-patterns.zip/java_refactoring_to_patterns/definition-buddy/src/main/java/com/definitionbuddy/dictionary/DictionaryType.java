package com.definitionbuddy.dictionary;

public enum DictionaryType {

    GENERAL, LEGAL, MEDICAL
}
