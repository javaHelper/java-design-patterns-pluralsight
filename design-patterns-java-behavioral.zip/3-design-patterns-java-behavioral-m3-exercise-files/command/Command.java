package com.pluralsight.command;

//command
public interface Command {

	public void execute();
	
}
