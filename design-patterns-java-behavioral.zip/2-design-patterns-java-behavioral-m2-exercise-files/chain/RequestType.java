package com.pluralsight.chain;

public enum RequestType {
	CONFERENCE, PURCHASE;
}
